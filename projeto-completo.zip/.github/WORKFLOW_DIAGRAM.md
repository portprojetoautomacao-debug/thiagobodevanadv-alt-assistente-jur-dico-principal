# 📊 GitHub Actions - Diagrama de Workflows

## Visão Geral da Arquitetura

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        GitHub Repository                                 │
│                   assistente-juridico-pje                                │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┴───────────────┐
                    ▼                               ▼
        ┌──────────────────┐              ┌──────────────────┐
        │   Push Event     │              │   PR Event       │
        │   to any branch  │              │   to main/dev    │
        └────────┬─────────┘              └────────┬─────────┘
                 │                                  │
     ┌───────────┼───────────┬──────────────────────┤
     ▼           ▼           ▼                      ▼
┌─────────┐ ┌─────────┐ ┌──────────┐       ┌─────────────┐
│   CI    │ │  Code   │ │ Nightly  │       │  PR Check   │
│Workflow │ │ Quality │ │  Build   │       │  Workflow   │
└────┬────┘ └────┬────┘ └────┬─────┘       └──────┬──────┘
     │           │            │                     │
     └───────────┴────────────┴─────────────────────┘
                           │
                ┌──────────┴──────────┐
                ▼                     ▼
        ┌──────────────┐      ┌─────────────┐
        │    Deploy    │      │   Release   │
        │   Workflow   │      │  Workflow   │
        └──────────────┘      └─────────────┘
                │                     │
                ▼                     ▼
        ┌──────────────┐      ┌─────────────┐
        │    Vercel    │      │   GitHub    │
        │  Production  │      │   Release   │
        └──────────────┘      └─────────────┘
```

## Fluxo Detalhado por Evento

### 1️⃣ Push em Qualquer Branch

```
git push origin feature-branch
         │
         ▼
┌─────────────────────────────────────┐
│         CI Workflow                 │
├─────────────────────────────────────┤
│ Jobs em paralelo:                   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  build-and-test             │   │
│ │  - Node 18.x: Build + Test  │   │
│ │  - Node 20.x: Build + Test  │   │
│ └─────────────────────────────┘   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  lint-security              │   │
│ │  - ESLint                   │   │
│ │  - NPM Audit                │   │
│ │  - SARIF Report             │   │
│ └─────────────────────────────┘   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  build-matrix-status        │   │
│ │  - Verifica se passou       │   │
│ └─────────────────────────────┘   │
└─────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│      Code Quality Workflow          │
├─────────────────────────────────────┤
│ Jobs em paralelo:                   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  codeql-analysis            │   │
│ │  - Security scanning        │   │
│ └─────────────────────────────┘   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  type-check                 │   │
│ │  - TypeScript verification  │   │
│ └─────────────────────────────┘   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  bundle-size                │   │
│ │  - Size analysis            │   │
│ └─────────────────────────────┘   │
└─────────────────────────────────────┘
```

### 2️⃣ Push para Branch Main

```
git push origin main
         │
         ▼
    (CI + Code Quality executam primeiro)
         │
         ▼
┌─────────────────────────────────────┐
│       Deploy Workflow               │
├─────────────────────────────────────┤
│  deploy-vercel:                     │
│  1. Checkout código                 │
│  2. Setup Node.js 20.x              │
│  3. npm ci                          │
│  4. npm run build                   │
│  5. Deploy Vercel --prod            │
│  6. Comment URL em PR (se houver)   │
└─────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│         Vercel CDN                  │
│    https://seu-app.vercel.app       │
└─────────────────────────────────────┘
```

### 3️⃣ Pull Request

```
Abrir/Atualizar PR
         │
         ▼
┌─────────────────────────────────────┐
│       PR Workflow                   │
├─────────────────────────────────────┤
│ Jobs em paralelo:                   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  pr-validation              │   │
│ │  - Check merge conflicts    │   │
│ │  - Lint                     │   │
│ │  - Build                    │   │
│ │  - Tests                    │   │
│ │  - package-lock validation  │   │
│ │  - Comment summary          │   │
│ └─────────────────────────────┘   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  pr-labeler                 │   │
│ │  - Auto-add labels          │   │
│ │  - Based on changed files   │   │
│ └─────────────────────────────┘   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  size-limit                 │   │
│ │  - Check bundle size        │   │
│ │  - Fail if > 300KB          │   │
│ └─────────────────────────────┘   │
└─────────────────────────────────────┘
         │
         ▼
    (CI + Code Quality também executam)
         │
         ▼
┌─────────────────────────────────────┐
│    dependency-review                │
│    - Check new dependencies         │
│    - Security vulnerabilities       │
└─────────────────────────────────────┘
```

### 4️⃣ Tag de Release

```
git tag v1.0.0
git push origin v1.0.0
         │
         ▼
┌─────────────────────────────────────┐
│      Release Workflow               │
├─────────────────────────────────────┤
│  create-release:                    │
│  1. Checkout código                 │
│  2. Setup Node.js                   │
│  3. npm ci                          │
│  4. npm run build (produção)        │
│  5. Criar ZIP do build              │
│  6. Gerar changelog                 │
│  7. Criar GitHub Release            │
│  8. Anexar ZIP                      │
│  9. Trigger deploy produção         │
└─────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│       GitHub Release                │
│   v1.0.0 com build ZIP              │
└─────────────────────────────────────┘
```

### 5️⃣ Nightly Build (Agendado)

```
Todo dia às 2h UTC
         │
         ▼
┌─────────────────────────────────────┐
│     Nightly Build Workflow          │
├─────────────────────────────────────┤
│ Jobs em paralelo:                   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  nightly-build              │   │
│ │  - Checkout develop         │   │
│ │  - npm audit                │   │
│ │  - npm outdated             │   │
│ │  - Lint                     │   │
│ │  - Build                    │   │
│ │  - Tests + Coverage         │   │
│ │  - Upload artifacts         │   │
│ │  - Create report            │   │
│ └─────────────────────────────┘   │
│                                     │
│ ┌─────────────────────────────┐   │
│ │  dependency-update-check    │   │
│ │  - npm-check-updates        │   │
│ │  - Suggest updates          │   │
│ └─────────────────────────────┘   │
└─────────────────────────────────────┘
```

## Matriz de Permissões

| Workflow       | Job                      | Permissions                                    |
|----------------|--------------------------|------------------------------------------------|
| **CI**         | build-and-test           | `contents: read`                               |
| **CI**         | lint-security            | `contents: read`, `security-events: write`     |
| **CI**         | build-matrix-status      | `contents: read`                               |
| **Deploy**     | deploy-vercel            | `contents: read`, `deployments: write`         |
| **Deploy**     | deploy-notification      | `contents: read`                               |
| **Quality**    | codeql-analysis          | `contents: read`, `security-events: write`     |
| **Quality**    | dependency-review        | `contents: read`, `pull-requests: write`       |
| **Quality**    | type-check               | `contents: read`                               |
| **Quality**    | bundle-size              | `contents: read`                               |
| **PR**         | pr-validation            | `contents: read`, `pull-requests: write`       |
| **PR**         | pr-labeler               | `contents: read`, `pull-requests: write`       |
| **PR**         | size-limit               | `contents: read`                               |
| **Release**    | create-release           | `contents: write`                              |
| **Release**    | notify-release           | `contents: read`                               |
| **Nightly**    | nightly-build            | `contents: read`                               |
| **Nightly**    | dependency-update-check  | `contents: read`                               |

## Dependências entre Workflows

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  Push → CI (obrigatório)                           │
│       → Code Quality (obrigatório)                 │
│                                                     │
│  Push (main) → CI + Quality + Deploy               │
│                                                     │
│  PR → CI + Quality + PR Check + Dependency Review  │
│                                                     │
│  Tag → Release → Deploy (produção)                 │
│                                                     │
│  Schedule → Nightly (independente)                 │
│                                                     │
└─────────────────────────────────────────────────────┘
```

## Tempo de Execução Estimado

| Workflow       | Tempo Médio | Tempo Máximo |
|----------------|-------------|--------------|
| CI             | 2-3 min     | 5 min        |
| Code Quality   | 5-7 min     | 10 min       |
| Deploy         | 3-4 min     | 7 min        |
| PR Validation  | 2-3 min     | 5 min        |
| Release        | 3-4 min     | 7 min        |
| Nightly        | 4-5 min     | 10 min       |

## Cache Strategy

```
┌─────────────────────────────────────┐
│         Cache Layers                │
├─────────────────────────────────────┤
│                                     │
│  1. npm cache                       │
│     Key: package-lock.json hash     │
│     Restore: node_modules/          │
│                                     │
│  2. TypeScript cache                │
│     Key: tsconfig + files hash      │
│     Restore: .tsbuildinfo            │
│                                     │
│  3. Vite build cache                │
│     Key: vite.config + deps         │
│     Restore: node_modules/.vite/    │
│                                     │
└─────────────────────────────────────┘
```

## Artifacts Gerados

| Workflow   | Artifact           | Retenção | Tamanho Aprox. |
|------------|--------------------|----------|----------------|
| CI         | build-18.x         | 7 dias   | ~2 MB          |
| CI         | build-20.x         | 7 dias   | ~2 MB          |
| CI         | eslint-results     | Sempre   | ~10 KB         |
| Nightly    | nightly-build-*    | 7 dias   | ~2 MB          |
| Release    | build-v*.zip       | Sempre   | ~2 MB          |

## Notificações

```
┌─────────────────────────────────────────────────────┐
│                Notificações Ativas                  │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ✅ Success → Nenhuma notificação (silencioso)     │
│                                                     │
│  ❌ Failure → Email + GitHub notification          │
│                                                     │
│  🔒 Security Alert → Email imediato                │
│                                                     │
│  📦 Outdated Deps → Weekly summary                 │
│                                                     │
└─────────────────────────────────────────────────────┘
```

## Integração com Ferramentas Externas

```
GitHub Actions
      │
      ├──► Vercel (Deploy)
      │    └─ Production + Preview deploys
      │
      ├──► CodeQL (Security)
      │    └─ Security alerts tab
      │
      ├──► Dependabot (Dependencies)
      │    └─ Automated PRs
      │
      └──► GitHub Packages (Future)
           └─ NPM package publishing
```

---

**Este diagrama representa a arquitetura completa dos workflows configurados.**
