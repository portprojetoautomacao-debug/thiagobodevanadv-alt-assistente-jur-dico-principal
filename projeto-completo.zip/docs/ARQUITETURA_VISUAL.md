# Arquitetura Visual - Agentes V2

## Diagrama de Arquitetura Completo

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         ASSISTENTE JURÍDICO V2                              │
│                    Multi-Agent System com Orquestração                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                              FRONTEND (React)                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │
│  │  Chat UI    │  │ Dashboard   │  │  Tarefas    │  │  Processos  │       │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘       │
└─────────┼────────────────┼────────────────┼────────────────┼────────────────┘
          │                │                │                │
          └────────────────┴────────────────┴────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          API LAYER (Vercel Functions)                       │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                      POST /api/agents-v2                              │ │
│  │  ┌──────────────────────────────────────────────────────────────┐    │ │
│  │  │  Input:                                                      │    │ │
│  │  │  {                                                           │    │ │
│  │  │    "agentId": "justine",                                     │    │ │
│  │  │    "message": "Processar intimações",                        │    │ │
│  │  │    "sessionId": "session-123"                                │    │ │
│  │  │  }                                                           │    │ │
│  │  └──────────────────────────────────────────────────────────────┘    │ │
│  │                              ▼                                        │ │
│  │  ┌──────────────────────────────────────────────────────────────┐    │ │
│  │  │  Output:                                                     │    │ │
│  │  │  {                                                           │    │ │
│  │  │    "ok": true,                                               │    │ │
│  │  │    "answer": "...",                                          │    │ │
│  │  │    "traces": [...],      ← NOVO: Observabilidade            │    │ │
│  │  │    "totalDuration": 1890 ← NOVO: Performance tracking       │    │ │
│  │  │  }                                                           │    │ │
│  │  └──────────────────────────────────────────────────────────────┘    │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                  GET /api/observability?action=health                 │ │
│  │  ┌──────────────────────────────────────────────────────────────┐    │ │
│  │  │  Status: 200 OK                                              │    │ │
│  │  │  {                                                           │    │ │
│  │  │    "status": "healthy",                                      │    │ │
│  │  │    "apis": {                                                 │    │ │
│  │  │      "healthy": ["djen-api", "todoist-api"],                 │    │ │
│  │  │      "down": ["pje-api"]                                     │    │ │
│  │  │    }                                                         │    │ │
│  │  │  }                                                           │    │ │
│  │  └──────────────────────────────────────────────────────────────┘    │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                       ORCHESTRATION LAYER                                   │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                      AgentOrchestrator                               │  │
│  │                                                                      │  │
│  │  Pattern: SEQUENTIAL                                                │  │
│  │  ┌─────────┐        ┌─────────┐        ┌─────────┐                 │  │
│  │  │ Task 1  │  ───▶  │ Task 2  │  ───▶  │ Task 3  │                 │  │
│  │  │Justin-e │        │Prazos   │        │Justin-e │                 │  │
│  │  └─────────┘        └─────────┘        └─────────┘                 │  │
│  │                                                                      │  │
│  │  Pattern: PARALLEL                                                  │  │
│  │  ┌─────────┐                                                        │  │
│  │  │ Risco   │ ─┐                                                     │  │
│  │  └─────────┘  │                                                     │  │
│  │  ┌─────────┐  ├──▶  Resultado consolidado                          │  │
│  │  │Pesquisa │ ─┤                                                     │  │
│  │  └─────────┘  │                                                     │  │
│  │  ┌─────────┐  │                                                     │  │
│  │  │Financial│ ─┘                                                     │  │
│  │  └─────────┘                                                        │  │
│  │                                                                      │  │
│  │  Pattern: HIERARCHICAL                                              │  │
│  │       ┌─────────┐                                                   │  │
│  │       │ Harvey  │  (coordenador)                                    │  │
│  │       └────┬────┘                                                   │  │
│  │            │                                                         │  │
│  │    ┌───────┴───────┐                                                │  │
│  │    ▼               ▼                                                │  │
│  │  ┌─────┐       ┌─────┐                                             │  │
│  │  │Prazos│       │DJEN │                                             │  │
│  │  └─────┘       └─────┘                                             │  │
│  │                                                                      │  │
│  │  Pattern: COLLABORATIVE                                             │  │
│  │  ┌─────┐  ┌─────┐  ┌─────┐                                         │  │
│  │  │Harvey│  │Risco│  │Juris│  ───▶  Voto/Consenso                   │  │
│  │  └─────┘  └─────┘  └─────┘                                         │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           AGENT LAYER                                       │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                      SimpleAgent (Core Engine)                        │ │
│  │                                                                       │ │
│  │  ┌──────────────────────────────────────────────────────────┐        │ │
│  │  │            ReAct Pattern Loop (Max 6 steps)              │        │ │
│  │  │                                                          │        │ │
│  │  │  Step 1: THOUGHT                                         │        │ │
│  │  │  ┌─────────────────────────────────────────────┐         │        │ │
│  │  │  │ "Preciso buscar próxima intimação"         │         │        │ │
│  │  │  └─────────────────────────────────────────────┘         │        │ │
│  │  │          ▼                                               │        │ │
│  │  │  Step 2: ACTION                                          │        │ │
│  │  │  ┌─────────────────────────────────────────────┐         │        │ │
│  │  │  │ Tool: buscarIntimacaoPendente               │         │        │ │
│  │  │  │ Args: {}                                    │         │        │ │
│  │  │  └─────────────────────────────────────────────┘         │        │ │
│  │  │          ▼                                               │        │ │
│  │  │  Step 3: OBSERVATION                                     │        │ │
│  │  │  ┌─────────────────────────────────────────────┐         │        │ │
│  │  │  │ "Encontrada intimação 123456..."            │         │        │ │
│  │  │  └─────────────────────────────────────────────┘         │        │ │
│  │  │          ▼                                               │        │ │
│  │  │  Step 4: FINAL ANSWER                                    │        │ │
│  │  │  ┌─────────────────────────────────────────────┐         │        │ │
│  │  │  │ "Intimação processada com sucesso"          │         │        │ │
│  │  │  └─────────────────────────────────────────────┘         │        │ │
│  │  │                                                          │        │ │
│  │  │  Traces: [                                               │        │ │
│  │  │    {step: 1, type: "thought", duration: 150ms},          │        │ │
│  │  │    {step: 2, type: "action", duration: 890ms},           │        │ │
│  │  │    {step: 3, type: "observation", duration: 50ms},       │        │ │
│  │  │    {step: 4, type: "final", duration: 100ms}             │        │ │
│  │  │  ]                                                       │        │ │
│  │  └──────────────────────────────────────────────────────────┘        │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                    15 Specialized Agents                              │ │
│  │                                                                       │ │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │ │
│  │  │  Harvey  │ │ Justin-e │ │ Análise  │ │Monitor   │ │  Prazos  │   │ │
│  │  │ (Strategy)│ │(Intimação)│ │(Docs)    │ │(DJEN)    │ │(Deadline)│   │ │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘   │ │
│  │                                                                       │ │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │ │
│  │  │ Redação  │ │Arquivos  │ │Pesquisa  │ │  Risco   │ │Contratual│   │ │
│  │  │(Petições)│ │  (Doc)   │ │(Juris)   │ │(Análise) │ │(Revisão) │   │ │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘   │ │
│  │                                                                       │ │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │ │
│  │  │Comunica  │ │Financeiro│ │Estratégia│ │ Tradução │ │Compliance│   │ │
│  │  │(Clientes)│ │(Honorár) │ │(Process) │ │(Jurídica)│ │(Audit)   │   │ │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘   │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           TOOLS LAYER (6 Tools)                             │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     Tool: buscarIntimacaoPendente                   │   │
│  │  ┌──────────────────────────────────────────────────────────┐      │   │
│  │  │  Circuit Breaker: djen-api                               │      │   │
│  │  │  State: CLOSED (healthy)                                 │      │   │
│  │  │  Failures: 0 / Threshold: 5                              │      │   │
│  │  └──────────────────────────────────────────────────────────┘      │   │
│  │         ▼                                                           │   │
│  │  API: POST /api/djen/check                                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     Tool: criarTarefa                               │   │
│  │  ┌──────────────────────────────────────────────────────────┐      │   │
│  │  │  Circuit Breaker: todoist-api                            │      │   │
│  │  │  State: CLOSED (healthy)                                 │      │   │
│  │  └──────────────────────────────────────────────────────────┘      │   │
│  │         ▼                                                           │   │
│  │  API: POST /api/todoist                                             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     Tool: calcularPrazos                            │   │
│  │  ┌──────────────────────────────────────────────────────────┐      │   │
│  │  │  Circuit Breaker: deadline-api                           │      │   │
│  │  │  State: CLOSED (healthy)                                 │      │   │
│  │  └──────────────────────────────────────────────────────────┘      │   │
│  │         ▼                                                           │   │
│  │  API: POST /api/deadline/calculate                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     Tool: consultarProcessoPJe                      │   │
│  │  ┌──────────────────────────────────────────────────────────┐      │   │
│  │  │  Circuit Breaker: pje-api                                │      │   │
│  │  │  State: OPEN (down) ⚠️                                    │      │   │
│  │  │  Failures: 5 / 5                                         │      │   │
│  │  │  Retry in: 45s                                           │      │   │
│  │  └──────────────────────────────────────────────────────────┘      │   │
│  │         ▼                                                           │   │
│  │  API: POST /api/legal-services  (bloqueado)                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     Tool: enviarMensagemWhatsApp                    │   │
│  │  ┌──────────────────────────────────────────────────────────┐      │   │
│  │  │  Circuit Breaker: evolution-api                          │      │   │
│  │  │  State: HALF_OPEN (testing) 🔶                           │      │   │
│  │  │  Successes: 1 / 2 needed                                 │      │   │
│  │  └──────────────────────────────────────────────────────────┘      │   │
│  │         ▼                                                           │   │
│  │  API: POST {EVOLUTION_API_URL}/message/sendText                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     Tool: registrarLogAgente                        │   │
│  │  ┌──────────────────────────────────────────────────────────┐      │   │
│  │  │  Circuit Breaker: kv-api                                 │      │   │
│  │  │  State: CLOSED (healthy)                                 │      │   │
│  │  └──────────────────────────────────────────────────────────┘      │   │
│  │         ▼                                                           │   │
│  │  API: POST /api/kv                                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      EXTERNAL SERVICES LAYER                                │
│                                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │
│  │ Spark LLM   │  │ Upstash KV  │  │   Todoist   │  │ Evolution   │       │
│  │ (via proxy) │  │   (Redis)   │  │    API      │  │  WhatsApp   │       │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘       │
│                                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │
│  │  DJEN API   │  │ DataJud API │  │   PJe API   │  │Legal Services│       │
│  │             │  │             │  │  (Justice)  │  │   (CNPJ)     │       │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘       │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      OBSERVABILITY & MONITORING                             │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                         Traces System                                 │ │
│  │                                                                       │ │
│  │  sessionId: session-123                                               │ │
│  │  traceId: trace-456                                                   │ │
│  │  agentId: justine                                                     │ │
│  │                                                                       │ │
│  │  Timeline:                                                            │ │
│  │  ├─ [00:00.000] Thought: "Preciso buscar intimação"         (150ms)  │ │
│  │  ├─ [00:00.150] Action: buscarIntimacaoPendente             (890ms)  │ │
│  │  ├─ [00:01.040] Observation: "Encontrada intimação..."      (50ms)   │ │
│  │  ├─ [00:01.090] Thought: "Vou calcular prazo"               (120ms)  │ │
│  │  ├─ [00:01.210] Action: calcularPrazos                      (450ms)  │ │
│  │  ├─ [00:01.660] Observation: "Prazo: 5 dias úteis"          (40ms)   │ │
│  │  └─ [00:01.700] Final Answer: "Tarefa criada com prazo"     (100ms)  │ │
│  │                                                                       │ │
│  │  Total Duration: 1.8s                                                 │ │
│  │  Tools Used: [buscarIntimacaoPendente, calcularPrazos]                │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                    Circuit Breakers Dashboard                         │ │
│  │                                                                       │ │
│  │  ✅ djen-api         [CLOSED]   0 failures   Healthy                 │ │
│  │  ✅ todoist-api      [CLOSED]   0 failures   Healthy                 │ │
│  │  ✅ deadline-api     [CLOSED]   1 failure    Healthy                 │ │
│  │  🔶 evolution-api    [HALF_OPEN] 3 failures  Testing (1/2 success)   │ │
│  │  ⚠️  pje-api         [OPEN]     5 failures   Down (retry in 45s)     │ │
│  │  ✅ kv-api           [CLOSED]   0 failures   Healthy                 │ │
│  │                                                                       │ │
│  │  Summary: 4 healthy | 1 degraded | 1 down                             │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Fluxo de Execução Detalhado

### 1. Requisição Entra

```
POST /api/agents-v2
{
  "agentId": "justine",
  "message": "Processar intimações pendentes"
}
```

### 2. Orquestrador Decide Pattern

```
Se (múltiplos agentes com dependências):
    Pattern = SEQUENTIAL
Senão se (múltiplos agentes independentes):
    Pattern = PARALLEL
Senão se (agente coordenador + subordinados):
    Pattern = HIERARCHICAL
Senão se (votação/consenso):
    Pattern = COLLABORATIVE
Senão:
    Execução single-agent
```

### 3. Agent Executa ReAct Loop

```
Loop (max 6 steps):
    1. LLM gera THOUGHT
       ├─ Log trace: {type: "thought", content: "...", duration: 150ms}
       └─ Decisão: preciso de ferramenta?
    
    2. Se (precisa ferramenta):
       ├─ LLM gera ACTION (JSON com tool + args)
       ├─ Log trace: {type: "action", toolUsed: "...", duration: 890ms}
       ├─ Circuit Breaker verifica API
       │  ├─ Se (CLOSED): executa normalmente
       │  ├─ Se (OPEN): lança erro (retry em Xs)
       │  └─ Se (HALF_OPEN): executa teste
       ├─ Executa tool com retry (3 tentativas)
       └─ Circuit Breaker registra resultado
    
    3. OBSERVATION do resultado
       └─ Log trace: {type: "observation", content: "...", duration: 50ms}
    
    4. Se (chegou em resposta final):
       ├─ Log trace: {type: "final", content: "...", duration: 100ms}
       └─ Break loop
```

### 4. Resposta Retorna

```json
{
  "ok": true,
  "agentId": "justine",
  "agentName": "Mrs. Justin-e",
  "steps": 4,
  "usedTools": ["buscarIntimacaoPendente", "calcularPrazos"],
  "answer": "Intimação 123456 processada. Prazo: 5 dias. Tarefa criada.",
  "traces": [
    {"step": 1, "type": "thought", "duration": 150},
    {"step": 2, "type": "action", "toolUsed": "buscarIntimacaoPendente", "duration": 890},
    {"step": 3, "type": "observation", "duration": 50},
    {"step": 4, "type": "final", "duration": 100}
  ],
  "totalDuration": 1890,
  "executionTimeMs": 2000,
  "timestamp": "2024-01-01T10:00:00Z"
}
```

## Circuit Breaker State Machine

```
┌─────────────────────────────────────────────────────────────────┐
│                   Circuit Breaker Lifecycle                     │
└─────────────────────────────────────────────────────────────────┘

  ESTADO INICIAL: CLOSED (tudo funcionando)
          │
          │ Requisições passam normalmente
          │
          ├─▶ Sucesso: failures = 0
          │
          ├─▶ Falha 1: failures = 1
          ├─▶ Falha 2: failures = 2
          ├─▶ Falha 3: failures = 3
          ├─▶ Falha 4: failures = 4
          ├─▶ Falha 5: failures = 5 ⚠️ THRESHOLD ATINGIDO
          │
          ▼
    ESTADO: OPEN (API bloqueada)
          │
          │ Bloqueia todas requisições
          │ Erro imediato: "Circuit breaker OPEN, retry em Xs"
          │
          │ Aguarda timeout (60s)
          │
          ▼
    ESTADO: HALF_OPEN (testando recuperação)
          │
          ├─▶ Teste 1 sucesso: successes = 1
          │   │
          │   ├─▶ Teste 2 sucesso: successes = 2 ✅ THRESHOLD ATINGIDO
          │   │       │
          │   │       └──▶ Volta para CLOSED ✅
          │   │
          │   └─▶ Teste 2 falha ❌
          │           │
          │           └──▶ Volta para OPEN ⚠️
          │
          └─▶ Teste 1 falha ❌
                  │
                  └──▶ Volta para OPEN ⚠️
```

## Comparação Antes vs Depois

### ANTES (Versão Simulada)

```
src/lib/agents.ts (629 linhas)
├── Math.random() × 50+
├── Dados inventados
├── Sem rastreamento
├── Sem resiliência
└── Monolítico

Frontend → /api/agents → Agente Único → Dados Fake ❌
```

### DEPOIS (Versão V2)

```
lib/ai/ (10 arquivos, 2.589 linhas)
├── core-agent.ts (ReAct + traces)
├── orchestrator (4 patterns)
├── circuit-breaker (resiliência)
├── tools (6 APIs reais)
├── registry (15 agentes)
└── Modular + testável

Frontend → /api/agents-v2 → Orchestrator → Agents → Tools → APIs Reais ✅
                                           ├── Traces
                                           ├── Circuit Breakers
                                           └── Observability
```

---

**Legenda**:
- ✅ Saudável (CLOSED)
- 🔶 Degradado (HALF_OPEN)
- ⚠️ Indisponível (OPEN)
- ❌ Problema crítico
- ▶ Fluxo de execução
- ─ Conexão/relação
